main() {
var mySize = 174;
print (mySize);
int yourSize=174;
print (yourSize);
double thisSize = 1.74;
print (thisSize);
}
